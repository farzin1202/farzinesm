import React, { createContext, useContext, useReducer, useEffect, useCallback } from 'react';
import { AppState, AppAction, Trade, Strategy, MonthData, User } from './types';
import { INITIAL_STATE } from './constants';
import { api } from './apiClient';

const STORAGE_KEY = 'tradeMaster_settings_v1';

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'LOAD_STATE':
      return { 
        ...state,
        strategies: action.payload.strategies || [],
        settings: { ...state.settings, ...action.payload.settings }
      };
    
    case 'LOGIN':
      return { ...state, user: action.payload };
    
    case 'LOGOUT':
      return { ...INITIAL_STATE, settings: state.settings, user: null };

    case 'UPDATE_USER':
      if (!state.user) return state;
      return { ...state, user: { ...state.user, ...action.payload } };

    case 'SET_THEME':
      return { ...state, settings: { ...state.settings, theme: action.payload } };
    case 'SET_LANGUAGE':
      return { ...state, settings: { ...state.settings, language: action.payload } };
    case 'COMPLETE_ONBOARDING':
      return { ...state, settings: { ...state.settings, isOnboardingComplete: true } };
    
    case 'ADD_STRATEGY':
      const newStrategy: Strategy = {
        id: action.payload,
        name: action.payload,
        months: []
      };
      return { ...state, strategies: [...state.strategies, newStrategy] };

    case 'UPDATE_STRATEGY':
      return {
        ...state,
        strategies: state.strategies.map(s =>
          s.id === action.payload.id ? { ...s, ...action.payload.updates } : s
        )
      };

    case 'DELETE_STRATEGY':
      return {
        ...state,
        strategies: state.strategies.filter(s => s.id !== action.payload),
        currentStrategyId: state.currentStrategyId === action.payload ? null : state.currentStrategyId
      };

    case 'SELECT_STRATEGY':
      return { ...state, currentStrategyId: action.payload, currentMonthId: null };

    case 'ADD_MONTH': {
      if (!state.currentStrategyId) return state;
      const newMonth: MonthData = {
        id: action.payload,
        name: action.payload,
        trades: []
      };
      return {
        ...state,
        strategies: state.strategies.map(s => 
          s.id === state.currentStrategyId 
            ? { ...s, months: [...s.months, newMonth] } 
            : s
        )
      };
    }

    case 'UPDATE_MONTH':
      return {
        ...state,
        strategies: state.strategies.map(s =>
          s.id === action.payload.strategyId
            ? {
                ...s,
                months: s.months.map(m =>
                  m.id === action.payload.monthId ? { ...m, ...action.payload.updates } : m
                )
              }
            : s
        )
      };

    case 'DELETE_MONTH': {
      if (!state.currentStrategyId) return state;
      return {
        ...state,
        strategies: state.strategies.map(s => 
          s.id === state.currentStrategyId 
            ? { ...s, months: s.months.filter(m => m.id !== action.payload) } 
            : s
        ),
        currentMonthId: state.currentMonthId === action.payload ? null : state.currentMonthId
      };
    }

    case 'SELECT_MONTH':
      return { ...state, currentMonthId: action.payload };

    case 'ADD_TRADE': {
      if (!state.currentStrategyId || !state.currentMonthId) return state;
      const newTrade = action.payload as Trade;
      return {
        ...state,
        strategies: state.strategies.map(s => {
          if (s.id !== state.currentStrategyId) return s;
          return {
            ...s,
            months: s.months.map(m => {
              if (m.id !== state.currentMonthId) return m;
              return { ...m, trades: [...m.trades, newTrade] };
            })
          };
        })
      };
    }

    case 'UPDATE_TRADE': {
        if (!state.currentStrategyId || !state.currentMonthId) return state;
        return {
          ...state,
          strategies: state.strategies.map(s => {
            if (s.id !== state.currentStrategyId) return s;
            return {
              ...s,
              months: s.months.map(m => {
                if (m.id !== state.currentMonthId) return m;
                return {
                  ...m,
                  trades: m.trades.map(t => t.id === action.payload.id ? { ...t, ...action.payload.data } : t)
                };
              })
            };
          })
        };
      }

    case 'DELETE_TRADE': {
        if (!state.currentStrategyId || !state.currentMonthId) return state;
        return {
          ...state,
          strategies: state.strategies.map(s => {
            if (s.id !== state.currentStrategyId) return s;
            return {
              ...s,
              months: s.months.map(m => {
                if (m.id !== state.currentMonthId) return m;
                return {
                  ...m,
                  trades: m.trades.filter(t => t.id !== action.payload)
                };
              })
            };
          })
        };
    }

    default:
      return state;
  }
}

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
  actions: {
    login: (email: string, password: string) => Promise<void>;
    register: (name: string, email: string, password: string) => Promise<void>;
    loadStrategies: () => Promise<void>;
    addStrategy: (name: string) => Promise<void>;
    updateStrategy: (id: string, updates: Partial<Strategy>) => Promise<void>;
    deleteStrategy: (id: string) => Promise<void>;
    addMonth: (name: string) => Promise<void>;
    updateMonth: (monthId: string, updates: { name?: string; notes?: string; aiAnalysis?: string }) => Promise<void>;
    deleteMonth: (monthId: string) => Promise<void>;
    addTrade: (trade: Partial<Trade>) => Promise<void>;
    updateTrade: (id: string, data: Partial<Trade>) => Promise<void>;
    deleteTrade: (id: string) => Promise<void>;
  };
}>({ 
  state: INITIAL_STATE, 
  dispatch: () => null,
  actions: {
    login: async () => {},
    register: async () => {},
    loadStrategies: async () => {},
    addStrategy: async () => {},
    updateStrategy: async () => {},
    deleteStrategy: async () => {},
    addMonth: async () => {},
    updateMonth: async () => {},
    deleteMonth: async () => {},
    addTrade: async () => {},
    updateTrade: async () => {},
    deleteTrade: async () => {},
  }
});

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const initializer = (initial: AppState): AppState => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return { ...initial, settings: { ...initial.settings, ...parsed.settings }, user: parsed.user };
      }
      return initial;
    } catch (e) {
      console.error("Failed to load settings from LocalStorage", e);
      return initial;
    }
  };

  const [state, dispatch] = useReducer(appReducer, INITIAL_STATE, initializer);

  useEffect(() => {
    const handler = setTimeout(() => {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ settings: state.settings, user: state.user }));
    }, 1000);
    return () => clearTimeout(handler);
  }, [state.settings, state.user]);

  useEffect(() => {
    if (state.settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [state.settings.theme]);

  const loadStrategies = useCallback(async () => {
    if (!state.user) return;
    try {
      const strategies = await api.strategies.getAll(state.user.id);
      dispatch({ type: 'LOAD_STATE', payload: { ...state, strategies } });
    } catch (error) {
      console.error('Failed to load strategies:', error);
    }
  }, [state.user]);

  useEffect(() => {
    if (state.user) {
      loadStrategies();
    }
  }, [state.user?.id]);

  const actions = {
    login: async (email: string, password: string) => {
      const { user } = await api.auth.login(email, password);
      dispatch({ type: 'LOGIN', payload: user });
    },
    register: async (name: string, email: string, password: string) => {
      await api.auth.register(name, email, password);
    },
    loadStrategies,
    addStrategy: async (name: string) => {
      if (!state.user) return;
      const strategy = await api.strategies.create(state.user.id, name);
      dispatch({ type: 'ADD_STRATEGY', payload: strategy.id });
      dispatch({ type: 'UPDATE_STRATEGY', payload: { id: strategy.id, updates: { name: strategy.name, months: [] } } });
    },
    updateStrategy: async (id: string, updates: Partial<Strategy>) => {
      await api.strategies.update(id, updates);
      dispatch({ type: 'UPDATE_STRATEGY', payload: { id, updates } });
    },
    deleteStrategy: async (id: string) => {
      await api.strategies.delete(id);
      dispatch({ type: 'DELETE_STRATEGY', payload: id });
    },
    addMonth: async (name: string) => {
      if (!state.currentStrategyId) return;
      const month = await api.months.create(state.currentStrategyId, name);
      dispatch({ type: 'ADD_MONTH', payload: month.id });
      dispatch({ type: 'UPDATE_MONTH', payload: { strategyId: state.currentStrategyId, monthId: month.id, updates: { name: month.name, trades: [] } } });
    },
    updateMonth: async (monthId: string, updates: { name?: string; notes?: string; aiAnalysis?: string }) => {
      if (!state.currentStrategyId) return;
      await api.months.update(monthId, updates);
      dispatch({ type: 'UPDATE_MONTH', payload: { strategyId: state.currentStrategyId, monthId, updates } });
    },
    deleteMonth: async (monthId: string) => {
      await api.months.delete(monthId);
      dispatch({ type: 'DELETE_MONTH', payload: monthId });
    },
    addTrade: async (tradeData: Partial<Trade>) => {
      if (!state.currentMonthId) return;
      
      const strategy = state.strategies.find(s => s.id === state.currentStrategyId);
      const month = strategy?.months.find(m => m.id === state.currentMonthId);
      const lastPair = month && month.trades.length > 0 
        ? month.trades[month.trades.length - 1].pair 
        : 'EURUSD';
      
      const fullTrade = {
        date: new Date().getDate().toString(),
        pair: lastPair,
        direction: 'Long' as const,
        rr: 2, 
        result: 'BE' as const,
        pips: 0,
        pnlPercent: 0,
        maxExcursionPercent: 0,
        ...tradeData
      };
      
      const trade = await api.trades.create(state.currentMonthId, fullTrade);
      dispatch({ type: 'ADD_TRADE', payload: trade });
    },
    updateTrade: async (id: string, data: Partial<Trade>) => {
      await api.trades.update(id, data);
      dispatch({ type: 'UPDATE_TRADE', payload: { id, data } });
    },
    deleteTrade: async (id: string) => {
      await api.trades.delete(id);
      dispatch({ type: 'DELETE_TRADE', payload: id });
    },
  };

  return (
    <AppContext.Provider value={{ state, dispatch, actions }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => useContext(AppContext);
