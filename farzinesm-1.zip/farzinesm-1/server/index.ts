import express from 'express';
import cors from 'cors';
import bcrypt from 'bcrypt';
import pool, { initDB } from './db.js';

const app = express();
app.use(cors());
app.use(express.json());

const PORT = 3001;

initDB().catch(console.error);

app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const passwordHash = await bcrypt.hash(password, 10);
    const avatarUrl = `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random`;
    
    const result = await pool.query(
      'INSERT INTO users (name, email, password_hash, avatar_url) VALUES ($1, $2, $3, $4) RETURNING id, name, email, avatar_url',
      [name, email, passwordHash, avatarUrl]
    );
    
    const user = result.rows[0];
    res.json({ user: { id: user.id.toString(), name: user.name, email: user.email, avatarUrl: user.avatar_url } });
  } catch (error: any) {
    if (error.code === '23505') {
      res.status(400).json({ error: 'Email already exists' });
    } else {
      console.error(error);
      res.status(500).json({ error: 'Server error' });
    }
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    
    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const user = result.rows[0];
    const validPassword = await bcrypt.compare(password, user.password_hash);
    
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    res.json({ user: { id: user.id.toString(), name: user.name, email: user.email, avatarUrl: user.avatar_url } });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/strategies/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const strategiesResult = await pool.query('SELECT * FROM strategies WHERE user_id = $1 ORDER BY created_at', [userId]);
    
    const strategies = await Promise.all(strategiesResult.rows.map(async (strategy) => {
      const monthsResult = await pool.query('SELECT * FROM months WHERE strategy_id = $1 ORDER BY created_at', [strategy.id]);
      
      const months = await Promise.all(monthsResult.rows.map(async (month) => {
        const tradesResult = await pool.query('SELECT * FROM trades WHERE month_id = $1 ORDER BY created_at', [month.id]);
        return {
          id: month.id.toString(),
          name: month.name,
          notes: month.notes,
          aiAnalysis: month.ai_analysis,
          trades: tradesResult.rows.map(t => ({
            id: t.id.toString(),
            date: t.date,
            pair: t.pair,
            direction: t.direction,
            rr: parseFloat(t.rr),
            result: t.result,
            pips: t.pips,
            pnlPercent: parseFloat(t.pnl_percent),
            maxExcursionPercent: t.max_excursion_percent ? parseFloat(t.max_excursion_percent) : undefined,
            notes: t.notes
          }))
        };
      }));
      
      return { id: strategy.id.toString(), name: strategy.name, notes: strategy.notes, months };
    }));
    
    res.json(strategies);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/strategies', async (req, res) => {
  try {
    const { userId, name } = req.body;
    const result = await pool.query(
      'INSERT INTO strategies (user_id, name) VALUES ($1, $2) RETURNING id, name',
      [userId, name]
    );
    res.json({ id: result.rows[0].id.toString(), name: result.rows[0].name, months: [] });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/strategies/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, notes } = req.body;
    await pool.query('UPDATE strategies SET name = COALESCE($1, name), notes = COALESCE($2, notes) WHERE id = $3', [name, notes, id]);
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/strategies/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await pool.query('DELETE FROM strategies WHERE id = $1', [id]);
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/months', async (req, res) => {
  try {
    const { strategyId, name } = req.body;
    const result = await pool.query(
      'INSERT INTO months (strategy_id, name) VALUES ($1, $2) RETURNING id, name',
      [strategyId, name]
    );
    res.json({ id: result.rows[0].id.toString(), name: result.rows[0].name, trades: [] });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/months/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, notes, aiAnalysis } = req.body;
    await pool.query(
      'UPDATE months SET name = COALESCE($1, name), notes = COALESCE($2, notes), ai_analysis = COALESCE($3, ai_analysis) WHERE id = $4',
      [name, notes, aiAnalysis, id]
    );
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/months/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await pool.query('DELETE FROM months WHERE id = $1', [id]);
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/trades', async (req, res) => {
  try {
    const { monthId, date, pair, direction, rr, result, pips, pnlPercent, maxExcursionPercent, notes } = req.body;
    const queryResult = await pool.query(
      `INSERT INTO trades (month_id, date, pair, direction, rr, result, pips, pnl_percent, max_excursion_percent, notes)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *`,
      [monthId, date, pair, direction, rr, result, pips, pnlPercent, maxExcursionPercent || null, notes || null]
    );
    const t = queryResult.rows[0];
    res.json({
      id: t.id.toString(),
      date: t.date,
      pair: t.pair,
      direction: t.direction,
      rr: parseFloat(t.rr),
      result: t.result,
      pips: t.pips,
      pnlPercent: parseFloat(t.pnl_percent),
      maxExcursionPercent: t.max_excursion_percent ? parseFloat(t.max_excursion_percent) : undefined,
      notes: t.notes
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/trades/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { date, pair, direction, rr, result, pips, pnlPercent, maxExcursionPercent, notes } = req.body;
    await pool.query(
      `UPDATE trades SET 
        date = COALESCE($1, date), 
        pair = COALESCE($2, pair), 
        direction = COALESCE($3, direction), 
        rr = COALESCE($4, rr), 
        result = COALESCE($5, result), 
        pips = COALESCE($6, pips), 
        pnl_percent = COALESCE($7, pnl_percent), 
        max_excursion_percent = COALESCE($8, max_excursion_percent),
        notes = COALESCE($9, notes)
       WHERE id = $10`,
      [date, pair, direction, rr, result, pips, pnlPercent, maxExcursionPercent, notes, id]
    );
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/trades/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await pool.query('DELETE FROM trades WHERE id = $1', [id]);
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on http://0.0.0.0:${PORT}`);
});
