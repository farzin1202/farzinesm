import pg from 'pg';
const { Pool } = pg;

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

export const initDB = async () => {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      email VARCHAR(255) UNIQUE NOT NULL,
      password_hash VARCHAR(255) NOT NULL,
      avatar_url TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS strategies (
      id SERIAL PRIMARY KEY,
      user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
      name VARCHAR(255) NOT NULL,
      notes TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS months (
      id SERIAL PRIMARY KEY,
      strategy_id INTEGER REFERENCES strategies(id) ON DELETE CASCADE,
      name VARCHAR(255) NOT NULL,
      notes TEXT,
      ai_analysis TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS trades (
      id SERIAL PRIMARY KEY,
      month_id INTEGER REFERENCES months(id) ON DELETE CASCADE,
      date VARCHAR(10) NOT NULL,
      pair VARCHAR(20) NOT NULL,
      direction VARCHAR(10) NOT NULL,
      rr DECIMAL(10,2) NOT NULL,
      result VARCHAR(10) NOT NULL,
      pips INTEGER NOT NULL,
      pnl_percent DECIMAL(10,2) NOT NULL,
      max_excursion_percent DECIMAL(10,2),
      notes TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
  `);
  console.log('Database initialized');
};

export default pool;
