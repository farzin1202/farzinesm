import { User, Strategy, Trade } from './types';

const API_BASE = '/api';

async function fetchAPI(endpoint: string, options?: RequestInit) {
  const res = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || 'API error');
  }
  return res.json();
}

export const api = {
  auth: {
    register: (name: string, email: string, password: string): Promise<{ user: User }> =>
      fetchAPI('/auth/register', { method: 'POST', body: JSON.stringify({ name, email, password }) }),
    
    login: (email: string, password: string): Promise<{ user: User }> =>
      fetchAPI('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }),
  },
  
  strategies: {
    getAll: (userId: string): Promise<Strategy[]> =>
      fetchAPI(`/strategies/${userId}`),
    
    create: (userId: string, name: string): Promise<Strategy> =>
      fetchAPI('/strategies', { method: 'POST', body: JSON.stringify({ userId, name }) }),
    
    update: (id: string, updates: Partial<Strategy>): Promise<void> =>
      fetchAPI(`/strategies/${id}`, { method: 'PUT', body: JSON.stringify(updates) }),
    
    delete: (id: string): Promise<void> =>
      fetchAPI(`/strategies/${id}`, { method: 'DELETE' }),
  },
  
  months: {
    create: (strategyId: string, name: string): Promise<{ id: string; name: string; trades: Trade[] }> =>
      fetchAPI('/months', { method: 'POST', body: JSON.stringify({ strategyId, name }) }),
    
    update: (id: string, updates: { name?: string; notes?: string; aiAnalysis?: string }): Promise<void> =>
      fetchAPI(`/months/${id}`, { method: 'PUT', body: JSON.stringify(updates) }),
    
    delete: (id: string): Promise<void> =>
      fetchAPI(`/months/${id}`, { method: 'DELETE' }),
  },
  
  trades: {
    create: (monthId: string, trade: Partial<Trade>): Promise<Trade> =>
      fetchAPI('/trades', { method: 'POST', body: JSON.stringify({ monthId, ...trade }) }),
    
    update: (id: string, updates: Partial<Trade>): Promise<void> =>
      fetchAPI(`/trades/${id}`, { method: 'PUT', body: JSON.stringify(updates) }),
    
    delete: (id: string): Promise<void> =>
      fetchAPI(`/trades/${id}`, { method: 'DELETE' }),
  },
};
